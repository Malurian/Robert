<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>

                <form method="POST" action="<?php echo e(url('event')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="text" placeholder="Event Title" name="name">
                    <input type="date" placeholder="Event Date" name="date">
                    <input type="text" placeholder="Event Address" name="address">
                    <input type="text" placeholder="Event Map" name="map">
                    <input type="text" placeholder="Event Description" name="description">
                    <input type="file" name="image">

                    <button type="submit" class="btn">
                        create
                    </button>
                </form>

<br>
<br>
<br>

                <div>
                    subscribed events <br>

                    <?php $__empty_1 = true; $__currentLoopData = $my_subscribed_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo e($event->event->name); ?>

                    <form method="POST" action="<?php echo e(url('subscribe', $event->id)); ?>">
                        <input type="hidden" name="_method" value="delete" />
                        <?php echo csrf_field(); ?>

                        <button type="submit" class="btn">
                            Un-Subscribe
                        </button>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        you have not subscribed for any event
                    <?php endif; ?>
                </div>

<br>
<br>
<br>

                <div>
                    created events <br>

                    <?php $__empty_1 = true; $__currentLoopData = $my_created_events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php echo e($event->name); ?>

                    <form method="POST" action="<?php echo e(url('event', $event->id)); ?>">
                        <input type="hidden" name="_method" value="delete" />
                        <?php echo csrf_field(); ?>

                        <button type="submit" class="btn">
                            Delete Event
                        </button>
                    </form>
                    <a href="<?php echo e(url('subscriber/'.$event->id )); ?>">View Event Subscribers</a>

                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        You have Created Any Event
                    <?php endif; ?>


                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\robert\resources\views/home.blade.php ENDPATH**/ ?>