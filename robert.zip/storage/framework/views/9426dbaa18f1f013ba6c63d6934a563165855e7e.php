<?php $__env->startSection('content'); ?>
					<div class=" content-area">
						<div class="page-header">
							<h4 class="page-title">Create an Event</h4>
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="#">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Create an Event</li>
							</ol>
						</div>
						<div class="row row-deck">
							<div class="col-lg">
								<form method="post" action="<?php echo e(url('event')); ?>" enctype="multipart/form-data" class="card">
										<?php echo csrf_field(); ?>

									<div class="card-header">
										<h3 class="card-title">Event elements</h3>
									</div>
									<div class="card-body">
										<div class="form-group">
											<label class="form-label">Event Title</label>
											<input type="text" class="form-control" name="name" placeholder="Event Name">
										</div>
                                        
                                        <label>Event Time:</label>
										<div class="wd-150 mg-b-30">
											<div class="input-group">
												<div class="input-group-prepend">
													<div class="input-group-text">
														<i class="fa fa-clock-o tx-16 lh-0 op-6"></i>
													</div>
												</div><!-- input-group-prepend -->
												<input class="form-control" id="tpBasic" placeholder="Set time" type="text">
											</div>
                                        </div>
                                        
										

										<div class="form-group">
											<label class="form-label">Event Description <span class="form-label-small ml-3">56/100</span></label>
											<textarea class="form-control" name="description" rows="7" placeholder="Description"></textarea>
										</div>

										<div class="form-group">
											<label class="form-label">Address</label>
												<input type="text" class="form-control" name="address" placeholder="Event Location">
											
										</div>

										<!-- <div class="form-group">
											<label class="form-label">Input group</label>
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search for...">
												<span class="input-group-append">
													<button class="btn btn-primary" type="button">Go!</button>
												</span>
											</div>
										</div> -->

										<div class="form-group ">
											<label class="form-label">Date of Event</label>
												<input type="date" class="form-control" name="date" placeholder="Event Date">
											
                                        </div>
                                        <div class="card-header">
                                            <h3 class="card-title">Event Image</h3>
                                        </div>
                                        <div class=" card-body">
                                            <div class="row">
                                                <div class="col-lg-4 col-sm-12">
                                                    <input type="file" class="dropify" name="image" data-height="180">
                                                </div>
                                            </div>
                                        </div>
									</div>
									<div class="card-footer text-right">
										<div class="d-flex">
											<a href="javascript:void(0)" class="btn btn-link">Cancel</a>
											<button type="submit" class="btn btn-primary ml-auto">Send data</button>
										</div>
									</div>
								</form>
							</div>
							<!-- <div class="col-lg-6">
							    <form method="post" class="card">
									<div class="card-header">
										<h3 class="card-title">Validation Form</h3>
									</div>
									<div class="card-body">
										<div class="form-group">
											<label class="form-label">Valid Email</label>
											<input type="text" class="form-control is-valid state-valid" name="example-text-input-valid" placeholder="Valid Email..">
										</div>
										<div class="form-group m-0">
											<label class="form-label">Invalid Number</label>
											<input type="text" class="form-control is-invalid state-invalid" name="example-text-input-invalid" placeholder="Invalid Number..">
											<div class="invalid-feedback">Invalid feedback</div>
										</div>
										<div class="form-group">
											<label class="form-label">Input group</label>
											<div class="input-group">
												<input type="text" class="form-control" placeholder="Search for...">
												<span class="input-group-append">
													<button class="btn btn-primary" type="button">Go!</button>
												</span>
											</div>
										</div>
										<div class="form-group">
											<label class="form-label">Input group buttons</label>
											<div class="input-group">
												<input type="text" class="form-control">
												<div class="input-group-append">
													<button type="button" class="btn btn-primary">Action</button>
													<button data-toggle="dropdown" type="button" class="btn btn-primary dropdown-toggle"></button>
													<div class="dropdown-menu dropdown-menu-right">
														<a class="dropdown-item" href="javascript:void(0)">News</a>
														<a class="dropdown-item" href="javascript:void(0)">Messages</a>
														<div class="dropdown-divider"></div>
														<a class="dropdown-item" href="javascript:void(0)">Edit Profile</a>
													</div>
												</div>
											</div>
										</div>
										<div class="form-group">
											<label class="form-label">Separated inputs</label>
											<div class="row gutters-xs">
												<div class="col">
													<input type="text" class="form-control" placeholder="Search for...">
												</div>
												<span class="col-auto">
													<button class="btn btn-secondary" type="button"><i class="fe fe-search"></i></button>
												</span>
											</div>
										</div>
										<div class="form-group">
											<label class="form-label">Icon input</label>
											<div class="input-icon mb-3">
												<input type="text" class="form-control" placeholder="Search for...">
												<span class="input-icon-addon search-icon">
													<i class="fe fe-search"></i>
												</span>
											</div>
											<div class="input-icon">
												<span class="input-icon-addon search-icon">
													<i class="fe fe-user"></i>
												</span>
												<input type="text" class="form-control" placeholder="Username">
											</div>
										</div>
										<div class="form-group">
											<label class="form-label">Disabled</label>
											<input type="text" class="form-control" name="example-disabled-input" placeholder="Disabled text area.." value="" disabled="">
										</div>
										<div class="form-group">
											<label class="form-label">Readonly</label>
											<input type="text" class="form-control" name="example-disabled-input" placeholder="Read Only Text area." value="Read Only Text area. " readonly="">
										</div>
									</div>
									<div class="card-footer text-right">
										<div class="d-flex">
											<a href="javascript:void(0)" class="btn btn-link">Cancel</a>
											<button type="submit" class="btn btn-primary ml-auto">Send data</button>
										</div>
									</div>
								</form>
							</div> -->
						</div>
						
					</div>
					<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\robert\resources\views/dashboard/create-events.blade.php ENDPATH**/ ?>